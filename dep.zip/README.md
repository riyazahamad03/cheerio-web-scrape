# cheerio-web-scrape
this application helps to track the product price of an amazon seamlessly

all you need is a bot configured 
1) token id
2) chat id 

replace both and start running 
